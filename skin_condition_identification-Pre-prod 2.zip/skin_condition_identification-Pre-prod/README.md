# skin_condition_identification
Enabling a simple self-diagnosis of melanoma by an end user. 
