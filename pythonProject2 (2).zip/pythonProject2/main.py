import json
import random

from flask import Flask, jsonify
from flask_restful import Api, Resource

app = Flask(__name__)
api = Api(app)


class Jokes(Resource):
    def get(self):
        jokes = [  "I ate a clock yesterday, it was very time-consuming.",
                   "Have you played the updated kids game? I Spy With My Little Eye . . . Phone.",
                   "A perfectionist walked into a bar...apparently, the bar was not set high enough.",
                   "You know it is going to be a bad day when the letters in your alphabet soup spell D-I-S-A-S-T-E-R.",
                   "Q. What is the difference between ignorance and apathy? A. I do not know and I do not care.",
                   "Did you hear about the semi-colon that broke the law? He was given two consecutive sentences.",
                   "Never criticize someone until you have walked a mile in their shoes. That way, when you criticize them, they will not be able to hear you from that far away. Plus, you will have their shoes.",
                   "I recently decided to sell my vacuum cleaner as all it was doing was gathering dust.",
                   "250 lbs here on Earth is 94.5 lbs on Mercury. No, I am not fat. I am just not on the right planet.",
                   "A lot of people cry when they cut onions. The trick is not to form an emotional bond."
                  ]
        response = {"jokes": random.choice(jokes)}
        return jsonify(response)


api.add_resource(Jokes, "/")
if __name__ == "__main__":
    app.run(port = 5000, host= "0.0.0.0", debug=True)
